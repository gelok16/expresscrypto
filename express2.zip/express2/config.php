<?php

//Configurado por TUDINEROWEB

// PHPSESSID
$phpsessid = "5dec8cf98c92d266383264fd6026c80a";

// DOGETOKEN
$dogetoken = "QPCe6aXS09mDWQJu0PHgB8sBJRpZ6nsQ";







?>
